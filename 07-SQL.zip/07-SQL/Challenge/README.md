# Module 7 | Assignment - Employee Database

Create entity relationship diagrams, perform data modeling and analysis on an employee database using SQL.
